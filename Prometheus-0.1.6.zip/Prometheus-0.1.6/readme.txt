





Tables Constructors are treated the way they are in LuaU, meaning that every Value will be assigned in the order it programmed
The Compiler does only support 64-bit doubles and 32-bit integers -> 64 bit Integer Literals will be converted to doubles