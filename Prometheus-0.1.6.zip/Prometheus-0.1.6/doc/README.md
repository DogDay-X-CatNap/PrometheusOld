---
description: Prometheus is an Lua Obfuscator, that is written in pure Lua.
---

# Prometheus

Prometheus can obfuscate Lua51 as well as Roblox's LuaU, which is an optionally typed superset of Lua51.

Show Prometheus on [github](https://github.com/levno-710/Prometheus).

This Documentation only applies to the newest version of Prometheus.
